<?php

$file = fopen('times.txt','r'); 
$times = ["8:00am" =>"", 
		   "9:00am" => "", 
           "10:00am" => "",
			"11:00am" => "", 
			"12:00pm" => "", 
                      "1:00pm" => "",
					  "2:00pm" =>"", 
					  "3:00pm" => "", 
                      "4:00pm" => "",
					  "5:00pm" =>""				  
					  ];
					  
while (!feof($file)){
$line = fgets($file);
$time = substr($line, 0 ,6); 
if($time != ''){ 
$times[$time] = substr($line,7); 
} 
}

foreach($times as $key => $value){
echo "<tr><td>$key</td>";
if($value==''){
echo "<td><input type='text' id='$key' name ='$key'></td></tr>\n"; 
} 
else{
echo "<td>$value</td></tr>\n" ;
}
} 

fclose($file); 

?> 