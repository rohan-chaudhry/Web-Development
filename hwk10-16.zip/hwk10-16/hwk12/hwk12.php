<!DOCTYPE html> 
<head>
<title> Rohan Chaudhry hwk 12 </title>
</head> 

<body>
<h1>Rohan Chaudhry | rc43755 | Hwk 12</h1>
<h2>Sign Up Sheet </h2>
<form id = 'registerValidate' action = './form-submit.php' method='post'> 
<table>
<tr> <th>Time</th><th>Name</th></tr>
<?php include 'form-times.php';?>
<tr>
<td colspan='2'>
<input type='submit' name='register' value='submit'>
<input type='reset' value='clear'>
</td>
</tr>
</table>
</form>
</body>
</html> 
