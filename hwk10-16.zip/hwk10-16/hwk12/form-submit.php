<?php

extract($_POST);
$file = fopen('times.txt','a'); 
$t1 = $_POST["8:00am"]; 
$t2 = $_POST["9:00am"]; 
$t3 = $_POST["10:00am"]; 
$t4 = $_POST["11:00am"]; 
$t5 = $_POST["12:00pm"]; 
$t6 = $_POST["1:00pm"]; 
$t7 = $_POST["2:00pm"]; 
$t8 = $_POST["3:00pm"]; 
$t9 = $_POST["4:00pm"]; 
$t10 = $_POST["5:00pm"]; 


if($t1 != ''){
fwrite($file, "08:00 $t1\n"); 
} 
if($t2 != ''){
fwrite($file, "09:00 $t2\n"); 
} 
if($t3 != ''){
fwrite($file, "10:00 $t3\n"); 
} 
if($t4 != ''){
fwrite($file, "11:00 $t4\n"); 
} 
if($t5 != ''){
fwrite($file, "12:00 $t5\n"); 
} 
if($t6 != ''){
fwrite($file, "01:00 $t6\n"); 
} 
if($t7 != ''){
fwrite($file, "02:00 $t7\n"); 
} 
if($t8 != ''){
fwrite($file, "03:00 $t8\n"); 
} 
if($t9 != ''){
fwrite($file, "04:00 $t9\n"); 
} 
if($t10 != ''){
fwrite($file, "05:00 $t10\n"); 
} 

fclose($file); 
print <<<CONF

<html>
<head>
<title>Confirmation</title>
</head>
<body>
<h1>You Are Registered</h1> 
<table border ='1'>
<tr><th colspan='2'>Sign Up Sheet</th></tr>
<tr><th>TIme</th><th>Name</th></tr> 
<tr><td>8:00am</td><td>$t1</td></tr>
<tr><td>9:00am</td><td>$t2</td></tr>
<tr><td>10:00am</td><td>$t3</td></tr>
<tr><td>11:00am</td><td>$t4</td></tr>
<tr><td>12:00pm</td><td>$t5</td></tr>
<tr><td>1:00pm</td><td>$t6</td></tr>
<tr><td>2:00pm</td><td>$t7</td></tr>
<tr><td>3:00pm</td><td>$t8</td></tr>
<tr><td>4:00pm</td><td>$t9</td></tr>
<tr><td>5:00pm</td><td>$t10</td></tr>
</table> 

<a href='https://fall-2018.cs.utexas.edu/cs329e-mitra/rohan97/index.html' target='_blank'>Main HW Index</a>

</body>
</html>
CONF;
?> 