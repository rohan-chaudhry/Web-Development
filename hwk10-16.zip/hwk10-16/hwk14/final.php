<?php
session_start(); 

if(isset($_SESSION['user'])){
  echo 'Congrats '. $_SESSION['user'] . "! You have successfully completed the quiz!\n\n\nFind your results below."  ; 
} else{
  echo 'pls log in.'; 
} 

?>

<html>
<head>
  <span></span>
</head> 
<body>
 <div> 
   <h1>RESULTS</h1>
 </div> 

</body>
</html> 

<?php

  
  
  $final = $_SESSION['score']*10; 
  echo "Your final score is ".$final." points."; 

  //write in results.txt 
  $str = $_SESSION['user'] . " : " . $final . "\n"; 
  $fh = fopen("./results.txt", "a"); 
  fwrite($fh, $str); 
  fclose($fh);
  echo "The results for ".$_SESSION['user']." have been logged in the results.txt file. This sesson will terminate shortly.";


 session_destroy(); 
?>