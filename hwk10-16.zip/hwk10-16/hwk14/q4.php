<?php
session_start(); 

if(isset($_SESSION['user'])){
 
   
} else{
  echo 'pls log in.'; 
} 

?>

<html>
<head>
  <span>Question 4</span>
</head> 
<body>
 <div>
   <h2 class="post-title">Multiple Choice<br/></h2>
   <h3> Q4</h3> 
   <br/>
   <form name="form4" method="post" >
        <table>
            <tr>
                <td>4. Stars that live the longest have ____ . </td>
            </tr>
            <tr>
                <td><input type="checkbox" name="q4[]" value="a1">high mass</td>
            </tr>
            <tr>
                <td><input type="checkbox" name="q4[]" value="a2"  >high temperature</td>
            </tr>
            <tr>
                <td><input type="checkbox" name="q4[]" value="a3">lots of hydrogen</td>
            </tr>
            <tr>
                <td><input type="checkbox" name="q4[]" value="a4" >small mass </td>
            </tr>

            <tr>
                <td><input type="submit" value="Submit Answer" name="submit"></td>
            </tr>
        </table>
    </form>
   <br/>
   <br/>
 </div> 

    <script>
       if (window.history && history.pushState) {
    addEventListener('load', function() {
        history.pushState(null, null, null); // creates new history entry with same URL
        addEventListener('popstate', function() {
            var stayOnPage = confirm("WARNING: Moving back is not allowed.");
            if (!stayOnPage) {
                history.back() 
            } else {
                history.pushState(null, null, null);
            }
        });    
    });
    }
   </script>

</body>
</html> 

<?php
$arr = array(); 
$sum = 0; 
if (isset($_POST['submit'])) {

  if(!empty($_POST['q4'])) {
    foreach($_POST['q4'] as $check) {
      $arr[] = $check; 
      if($check !== 'a4'){
        $sum++; 
} 
      if($check == 'a4'){
        $sum--; 
} 
}

if($sum>=0){ //wrong answers 
  header('Location: q5.php'); 
} else{ //correct 
   $_SESSION['score'] = $_SESSION['score'] + 1; 
   header('Location: q5.php'); 

} 

}}

 
?>