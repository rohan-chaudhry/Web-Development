<?php
   
    session_start();
?>

<html>
<head>
  <title> Rohan Chaudhry | Hwk14 Homepage </title>
</head>
<body> 
    <h1> Astrology Quiz Log In </h1> 
    <h3>  Rohan Chaudhry | Hwk 14 | rc43755 </h3>
    <form name="form1" method="post" >
        <table>
            <tr>
                <td>Username</td>
                <td><input type="text" name="text"></td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password" name="pwd"></td>
            </tr>
            <tr>
                <td><input type="submit" value="Sign In" name="submit"></td>
            </tr>
        </table>
    </form>

    <script>
       if (window.history && history.pushState) {
    addEventListener('load', function() {
        history.pushState(null, null, null); // creates new history entry with same URL
        addEventListener('popstate', function() {
            var stayOnPage = confirm("WARNING: Moving back is not allowed.");
            if (!stayOnPage) {
                history.back() 
            } else {
                history.pushState(null, null, null);
            }
        });    
    });
    }
   </script>
</body> 
</html>

<?php
    if (isset($_POST['submit'])) {
        $v1 = "FirstUser";
        $v2 = "MyPassword";
        $v3 = $_POST['text']; //username 
        $v4 = $_POST['pwd'];  // password 
        $cont = true;         
        //echo "name is " . $v3."  " ; //test 

        $file = fopen("passwd.txt", "r") or exit("Unable to open file!");
        //read each line of txt file 
        while(!feof($file)){
          if(strpos(fgets($file),$v3) !== false){
            echo "Please enter a unique username and password!";
            $cont = false; 
            header('Location: hwk14.php');
            echo "Please enter a unique username and password!";

            break;  
          } 
        }
        fclose($file);
         
       
	if($cont){
            $_SESSION['user'] = $v3; //user == username 
            $_SESSION['score'] = 0; //init score 
            $_SESSION['start'] = time(); // Taking now logged in time.
            // Ending a session in 15 minutes from the starting time.
            $_SESSION['expire'] = $_SESSION['start'] + (15 * 60);
	    //write in passwd.txt 
	    $str = $v3 . " : " . $v4 . "\n"; 
	    $fh = fopen("./passwd.txt", "a"); 
	    fwrite($fh, $str); 
	    fclose($fh);	
            //echo " Gang your score is ".$_SESSION['score']; //test 
            header('Location: q1.php'); 
	} 
        } 
?>