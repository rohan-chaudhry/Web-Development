<?php
session_start(); 

if(isset($_SESSION['user'])){
 
   
} else{
  echo 'pls log in.'; 
} 

?>

<html>
<head>
  <span>Question 5</span>
</head> 
<body>
 <div>
   <h2 class="post-title">Fill In The Blank<br/></h2>
   <h3> Q5</h3> 
   <br/>
   <form name="form5" method="post" >
        <table>
            <tr>
                <td>5. A collection of a hundred billion stars, gas, and dust is called a ____ . </td>
            </tr>
            <tr>
                <td><input type="text" name="q5" value=""></td>
            </tr>
            <tr>
                <td><input type="submit" value="Submit Answer" name="submit"></td>
            </tr>
        </table>
    </form>
   <br/>
   <br/>
 </div> 

    <script>
       if (window.history && history.pushState) {
    addEventListener('load', function() {
        history.pushState(null, null, null); // creates new history entry with same URL
        addEventListener('popstate', function() {
            var stayOnPage = confirm("WARNING: Moving back is not allowed.");
            if (!stayOnPage) {
                history.back() 
            } else {
                history.pushState(null, null, null);
            }
        });    
    });
    }
   </script>

</body>
</html> 

<?php 
$ans = $_POST['q5']; 
$sum = 0; 
if (isset($_POST['submit'])) {
  if(!empty($_POST['q5'])) {
      if(strtolower($ans) == 'galaxy'){
        $sum++; 
} 
}

if($sum>0){ //correct 
  $_SESSION['score'] = $_SESSION['score'] + 1; 
  header('Location: q6.php'); 
  echo 'CORRECT';  
} else{ //incorrect 
   header('Location: q6.php'); 
}}

 
?>