<?php
session_start(); 

if(isset($_SESSION['user'])){
  echo 'welcome '. $_SESSION['user'] . "! Let's begin the quiz!\n\n\n"  ; 
} else{
  echo 'pls log in.'; 
} 

?>

<html>
<head>
  <span>Question 1</span>
</head> 
<body>
 
 <div>
   <h2 class="post-title">
     True/False 
   </h2>
   <br/>
   <form name="form1" method="post" >
        <table>
            <tr>
                <td>1. According to Kepler the orbit of the earth is a circle with the sun at the center.</td>
            </tr>
            <tr>
                <td><input type="radio" name="q1" value="true" id='incorrectQ1'>True</td>
            </tr>
            <tr>
                <td><input type="radio" name="q1" value="false" id='correctQ1' >False</td>
            </tr>
            <tr>
                <td><input type="submit" value="Submit Answer" name="submit"></td>
            </tr>
        </table>
    </form>
   <br/>
   <br/>
 </div> 


    <script>
       if (window.history && history.pushState) {
    addEventListener('load', function() {
        history.pushState(null, null, null); // creates new history entry with same URL
        addEventListener('popstate', function() {
            var stayOnPage = confirm("WARNING: Moving back is not allowed.");
            if (!stayOnPage) {
                history.back() 
            } else {
                history.pushState(null, null, null);
            }
        });    
    });
    }
   </script>

</body>
</html> 

<?php

if (isset($_POST['submit'])) {
  $ans = $_POST['q1']; 
  if($ans == 'false'){ //if correct 
    $_SESSION['score'] = $_SESSION['score'] + 1; 
    header('Location: q2.php'); 

}
  else{ //if incorrect 
    header('Location: q2.php'); 

} 

}

?>