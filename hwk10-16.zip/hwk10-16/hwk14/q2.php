<?php
session_start(); 

if(isset($_SESSION['user'])){
   
} else{
  echo 'pls log in.'; 
} 

?>

<html>
<head>
  <span>Question 2</span>
</head> 
<body>
 <div>
   <h2 class="post-title">
     True/False 
   </h2>
   <br/>
   <form name="form2" method="post" >
        <table>
            <tr>
                <td>2. Ancient astronomers did consider the heliocentric model of the solar system but rejected it because they could not detect parallax.</td>
            </tr>
            <tr>
                <td><input type="radio" name="q2" value="true" id='correctQ1'>True</td>
            </tr>
            <tr>
                <td><input type="radio" name="q2" value="false" id='incorrectQ1' >False</td>
            </tr>
            <tr>
                <td><input type="submit" value="Submit Answer" name="submit"></td>
            </tr>
        </table>







    </form>
   <br/>
   <br/>
 </div> 


    <script>
       if (window.history && history.pushState) {
    addEventListener('load', function() {
        history.pushState(null, null, null); // creates new history entry with same URL
        addEventListener('popstate', function() {
            var stayOnPage = confirm("WARNING: Moving back is not allowed.");
            if (!stayOnPage) {
                history.back() 
            } else {
                history.pushState(null, null, null);
            }
        });    
    });
    }
   </script>


</body>
</html> 

<?php

if (isset($_POST['submit'])) {
  $ans = $_POST['q2']; 
  if($ans == 'true'){ //if correct 
    $_SESSION['score'] = $_SESSION['score'] + 1; 
    header('Location: q3.php'); 

}
  else{ //if incorrect 
    header('Location: q3.php'); 

} 

}

?>