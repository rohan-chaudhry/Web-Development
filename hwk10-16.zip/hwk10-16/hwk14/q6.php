<?php
session_start(); 

if(isset($_SESSION['user'])){
 
   
} else{
  echo 'pls log in.'; 
} 

?>

<html>
<head>
  <span>Question 6</span>
</head> 
<body>
 <div>
   <h2 class="post-title">Fill In The Blank<br/></h2>
   <h3> Q6</h3> 
   <br/>
   <form name="form6" method="post" >
        <table>
            <tr>
                <td>6. The inverse of the Hubble's constant is a measure of the _____ of the universe. </td>
            </tr>
            <tr>
                <td><input type="text" name="q6" value=""></td>
            </tr>
            <tr>
                <td><input type="submit" value="Submit Answer" name="submit"></td>
            </tr>
        </table>
    </form>
   <br/>
   <br/>
 </div> 

    <script>
       if (window.history && history.pushState) {
    addEventListener('load', function() {
        history.pushState(null, null, null); // creates new history entry with same URL
        addEventListener('popstate', function() {
            var stayOnPage = confirm("WARNING: Moving back is not allowed.");
            if (!stayOnPage) {
                history.back() 
            } else {
                history.pushState(null, null, null);
            }
        });    
    });
    }
   </script>

</body>
</html> 

<?php 
$ans = $_POST['q6']; 
$sum = 0; 
if (isset($_POST['submit'])) {
  if(!empty($_POST['q6'])) {
      if(strtolower($ans) == 'age'){
        $sum++; 
} 
}

if($sum>0){ //correct 
  $_SESSION['score'] = $_SESSION['score'] + 1; 
  header('Location: final.php'); 
  echo 'CORRECT';  
} else{ //incorrect 
   header('Location: final.php'); 
}}

 
?>