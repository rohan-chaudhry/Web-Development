<?php
session_start(); 

if(isset($_SESSION['user'])){
    
} else{
  echo 'pls log in.'; 
} 

?>

<html>
<head>
  <span>Question 3</span>
</head> 
<body>
 <div>
   <h2 class="post-title">Multiple Choice<br/></h2>
   <h3> Q3</h3> 
   <br/>
   <form name="form3" method="post" >
        <table>
            <tr>
                <td>3. The total amount of energy that a star emits is directly related to its ____ . </td>
            </tr>
            <tr>
                <td><input type="checkbox" name="q3[]" value="a1">surface gravity and magnetic field</td>
            </tr>
            <tr>
                <td><input type="checkbox" name="q3[]" value="a2"  >radius and temperature</td>
            </tr>
            <tr>
                <td><input type="checkbox" name="q3[]" value="a3">pressure and volume</td>
            </tr>
            <tr>
                <td><input type="checkbox" name="q3[]" value="a4" >location and velocity </td>
            </tr>

            <tr>
                <td><input type="submit" value="Submit Answer" name="submit"></td>
            </tr>
        </table>







    </form>
   <br/>
   <br/>
 </div> 

    <script>
       if (window.history && history.pushState) {
    addEventListener('load', function() {
        history.pushState(null, null, null); // creates new history entry with same URL
        addEventListener('popstate', function() {
            var stayOnPage = confirm("WARNING: Moving back is not allowed.");
            if (!stayOnPage) {
                history.back() 
            } else {
                history.pushState(null, null, null);
            }
        });    
    });
    }
   </script>

</body>
</html> 

<?php
$arr = array(); 
$sum = 0; 
if (isset($_POST['submit'])) {

  if(!empty($_POST['q3'])) {
    foreach($_POST['q3'] as $check) {
      $arr[] = $check; 
      if($check !== 'a2'){
        $sum++; 
} 
      if($check == 'a2'){
        $sum--; 
} 
}

if($sum>=0){ //wrong answers 
  header('Location: q4.php'); 
} else{ //correct 
   $_SESSION['score'] = $_SESSION['score'] + 1; 
   header('Location: q4.php'); 

} 

}}

 
?>