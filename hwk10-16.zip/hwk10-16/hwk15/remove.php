<?php
##id taken in from the form to transfer into the SQL query
$id = $_POST["id"];
##establish database variables
if ($id != "") {
  $host = "fall-2018.cs.utexas.edu";
  $user = "cs329e_mitra_shak";
  $pwd = "creamy$biopsy4apathy";
  $dbs = "cs329e_mitra_shak";

  $connect = mysqli_connect($host, $user, $pwd, $dbs);
  $table = "registered";
  $id = mysqli_real_escape_string($connect, $id);
  mysqli_query($connect, "DELETE FROM $table WHERE ID='$id'");
}
##form specifying what to delete
print <<<DELETE
  <html>
  <head>
  	<title>Remove Student Record</title>
  </head>

  <body>
  <form method = "post" action = "remove.php">
  <label for = "id">ID:</label>
  <input type = "text" name = "id" /><br /><br />
  <button type = "reset">Reset</button>
  <button type = "submit">Delete</button><br /><br />
  </form>
  <p>To return to the main menu, click <a href = "./hwk15.php">here</a>.</p>
  </body>
  </html>
DELETE;

?>
