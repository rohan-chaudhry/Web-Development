<?php
$id = $_POST["id"];
$last = $_POST["last"];
$first = $_POST["first"];
$major = $_POST["major"];
$gpa = $_POST["gpa"];

if (($id != "") and (($last != "") or ($first != "") or ($major != "") or ($gpa != ""))) {
  $host = "fall-2018.cs.utexas.edu";
  $user = "cs329e_mitra_shak";
  $pwd = "creamy$biopsy4apathy";
  $dbs = "cs329e_mitra_shak";

  $connect = mysqli_connect($host, $user, $pwd, $dbs);
  $table = "registered";
  $id = mysqli_real_escape_string($connect, $id);

  if ($last != "") {
    mysqli_query($connect, "UPDATE $table SET lastName='$last' WHERE id='$id'");
  }

  if ($first != "") {
    mysqli_query($connect, "UPDATE $table SET firstName='$first' WHERE id='$id'");
  }

  if ($major != "") {
    mysqli_query($connect, "UPDATE $table SET major='$major' WHERE id='$id'");
  }

  if ($gpa != "") {
    mysqli_query($connect, "UPDATE $table SET GPA='$gpa' WHERE id='$id'");
  }
}

print <<<UPDATE
  <html>
  <head>
  	<title>Update Student Record</title>
  </head>

  <body>
  <form method = "post" action = "update.php">
  <label for = "id">ID:</label>
  <input type = "text" name = "id" /><br /><br />
  <label for = "last">Last name:</label>
  <input type = "text" name = "last" /><br /><br />
  <label for = "first">First name:</label>
  <input type = "text" name = "first" /><br /><br />
  <label for = "major">Major:</label>
  <input type = "text" name = "major" /><br /><br />
  <label for = "gpa">GPA:</label>
  <input type = "text" name = "gpa" /><br /><br />
  <button type = "reset">Reset</button>
  <button type = "submit">Update</button><br /><br />
  </form>
  <p>To return to the main menu, click <a href = "./hwk15.php">here</a>.</p>
  </body>
  </html>
UPDATE;
?>
