<?php

session_start();

	$username = $_POST["username"];
	$password = $_POST["password"];
	$string_to_check = $username.":".$password;

	if (isset($_POST["logout"])){
		session_destroy();
		print "Logged out";
		return;
	}

	$readFile = fopen("passwd.txt", "r");
	$passwordArray[] = array();

	while (!feof($readFile)){
	
		$line = fgets($readFile);
		$passwordArray[] = rtrim($line);
	}

	if (in_array($string_to_check, $passwordArray)) {
  		$_SESSION["verified"] = true;
	}

if (!isset($_SESSION["verified"])) {
  print <<<LOGIN
  <html>
  <head>
  <title>Student Records Login</title>
  </head>

  <body>
  <form method = "post" action = "hwk15.php">
  <table border = "0">
    <tr>
      <td>Username</td>
      <td><input type = "text" name = "username" id = "username" /></td>
    </tr>
    <tr>
      <td>Password</td>
      <td><input type = "password" name = "password" id = "password" /></td>
    </tr>
    <tr>
      <td><button type = "reset">Reset</button></td>
      <td><button type = "submit">Submit</button></td>
    </tr>
  </table>
  </form>
  <br />
  <br />
LOGIN;


	if ($_POST["username"] != "") {
    		print "Login Failed";
	}
  print "</body>";
  print "</html>";
}

  if (isset($_POST["insert"])) {
    header("Location: insert.php");
  }

  if (isset($_POST["update"])) {
    header("Location: update.php");
  }

  if (isset($_POST["delete"])) {
    header("Location: remove.php");
  }

  if (isset($_POST["view"])) {
    header("Location: view.php");
  }

  print <<<LOGGEDIN
  <html>
  <head>
  <title>Update Student Database</title>
  </head>

  <body>
  <form method = "post" action = "hwk15.php"> 
    <button type = "submit" name = "insert">Insert Student Record</button><br /><br />
    <button type = "submit" name = "update">Update Student Record</button><br /><br />
    <button type = "submit" name = "delete">Delete Student Record</button><br /><br />
    <button type = "submit" name = "view">View Student Record</button><br /><br />
    <button type = "submit" name = "logout">Logout</button>
  </form>
  </body>
  </html>
LOGGEDIN;


?>