<?php
$id = $_POST["id"];
$last = $_POST["last"];
$first = $_POST["first"];

$host = "fall-2018.cs.utexas.edu";
$user = "cs329e_mitra_shak";
$pwd = "creamy$biopsy4apathy";
$dbs = "cs329e_mitra_shak";
$connect = mysqli_connect($host, $user, $pwd, $dbs);
$table = "registered";

print <<<VIEW
  <html>
  <head>
  	<title>View Student Record</title>
  </head>

  <body>
  <form method = "post" action = "view.php">
  <label for = "id">ID:</label>
  <input type = "text" name = "id" /><br /><br />
  <label for = "last">Last name:</label>
  <input type = "text" name = "last" /><br /><br />
  <label for = "first">First name:</label>
  <input type = "text" name = "first" /><br /><br />
  <button type = "reset">Reset</button>
  <button type = "submit">View</button>
  <button type = "submit" name = "viewAll">View All Student Records</button><br /><br />
  </form>
  <p>To return to the main menu, click <a href = "./hwk15.php">here</a>.</p><br /><br />
VIEW;
if (isset($_POST["viewAll"])) {
  $result = mysqli_query($connect, "SELECT * from $table ORDER BY lastName ASC, firstName ASC");
  print <<<TABLE
  <table border = '1'>
  <tr>
    <td>ID</td>
    <td>Last</td>
    <td>First</td>
    <td>Major</td>
    <td>GPA</td>
  </tr>
TABLE;
  while ($row = $result -> fetch_row()) {
    print "<tr>";
    print "<td>".$row[0]."</td>";
    print "<td>".$row[1]."</td>";
    print "<td>".$row[2]."</td>";
    print "<td>".$row[3]."</td>";
    print "<td>".$row[4]."</td>";
  }
  print "</table>";
}
elseif ($_POST["id"] != "") {
  $id = mysqli_real_escape_string($connect, $id);
  $result = mysqli_query($connect, "SELECT * from $table WHERE ID = '$id'");
  print <<<TABLE
  <table border = '1'>
  <tr>
    <td>ID</td>
    <td>Last</td>
    <td>First</td>
    <td>Major</td>
    <td>GPA</td>
  </tr>
TABLE;
  while ($row = $result -> fetch_row()) {
    print "<tr>";
    print "<td>".$row[0]."</td>";
    print "<td>".$row[1]."</td>";
    print "<td>".$row[2]."</td>";
    print "<td>".$row[3]."</td>";
    print "<td>".$row[4]."</td>";
  }
  print "</table>";
}
elseif (($_POST["first"] != "") and ($_POST["last"] != "")) {
  $first = mysqli_real_escape_string($connect, $first);
  $last = mysqli_real_escape_string($connect, $last);
  $result = mysqli_query($connect, "SELECT * from $table WHERE lastName = '$last' AND firstName = '$first'");
  print <<<TABLE
  <table border = '1'>
  <tr>
    <td>ID</td>
    <td>Last</td>
    <td>First</td>
    <td>Major</td>
    <td>GPA</td>
  </tr>
TABLE;
  while ($row = $result -> fetch_row()) {
    print "<tr>";
    print "<td>".$row[0]."</td>";
    print "<td>".$row[1]."</td>";
    print "<td>".$row[2]."</td>";
    print "<td>".$row[3]."</td>";
    print "<td>".$row[4]."</td>";
  }
  print "</table>";
}

##otherwise select table with all entries using specified last name OR order by first name ascending
elseif ($_POST["last"] != "") {
  $last = mysqli_real_escape_string($connect, $last);
  $result = mysqli_query($connect, "SELECT * from $table WHERE lastName = '$last' ORDER BY firstName ASC");
  print <<<TABLE
  <table border = '1'>
  <tr>
    <td>ID</td>
    <td>Last</td>
    <td>First</td>
    <td>Major</td>
    <td>GPA</td>
  </tr>
TABLE;
  while ($row = $result -> fetch_row()) {
    print "<tr>";
    print "<td>".$row[0]."</td>";
    print "<td>".$row[1]."</td>";
    print "<td>".$row[2]."</td>";
    print "<td>".$row[3]."</td>";
    print "<td>".$row[4]."</td>";
  }
  print "</table>";
}
elseif ($_POST["first"] != "") {
  $first = mysqli_real_escape_string($connect, $first);
  $result = mysqli_query($connect, "SELECT * from $table WHERE firstName = '$first' ORDER BY lastName ASC");
  print <<<TABLE
  <table border = '1'>
  <tr>
    <td>ID</td>
    <td>Last</td>
    <td>First</td>
    <td>Major</td>
    <td>GPA</td>
  </tr>
TABLE;
  while ($row = $result -> fetch_row()) {
    print "<tr>";
    print "<td>".$row[0]."</td>";
    print "<td>".$row[1]."</td>";
    print "<td>".$row[2]."</td>";
    print "<td>".$row[3]."</td>";
    print "<td>".$row[4]."</td>";
  }
  print "</table>";
}

print <<<BOTTOMVIEW
</body>
</html>
BOTTOMVIEW;

?>
