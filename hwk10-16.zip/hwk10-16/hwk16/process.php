<?php

if(isset($_POST['username']) && isset($_POST['password'])){
        $username = $_POST['username']; 
        $password = $_POST['password'];
        $encrypt = password_hash($password, PASSWORD_DEFAULT);  
	$cont = true; 	
	
	$file = fopen("passwd.txt", "r") or exit("Unable to open file!");
        //read each line of txt file 
        
        while(!feof($file)){
          if(strpos(fgets($file),$username) !== false){
            $ans = "usernameexists";
            $cont = false; 
            break;  
          } 
        }
        fclose($file);
		
	if($cont){
	    //write in passwd.txt  
	    $str = $username . " : " . $encrypt . "\n"; 
	    $fh = fopen("./passwd.txt", "a"); 
	    fwrite($fh, $str);
            $ans = "success";  
	    fclose($fh);	
            
	} 
} 
 
echo json_encode($ans); 
 
?> 