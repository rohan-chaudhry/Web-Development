$(document).ready(function(){
	
	
	$("#submit").click(function(){
	       var username = $("#username").val();  
	       var password = $("#password").val(); 

                console.log('user is '+username + ' and pw is '+password); 

		if(username.length == 0 || password.length==0){
			$("#submit").after("<br/><br/><div class='alert alert-danger'>Please fill out entries correctly"); 
		} 

		else{   
                        console.log('else'); 
     			$.post("process.php",
                        {username:username,password:password}, function(data){

                         console.log('in the func'); 
                         console.log(data +'is data'); 
                           if(data=='hello'){console.log('moves'); } 
                           if(data == '"usernameexists" '){
                               $("#submit").after("<br/><br/><div class='alert alert-danger'>Username is taken. Please enter a unique username.");
                            }
                           if(data == '"success" '){
                               console.log('in success'); 
                               $("#submit").after("<br/><br/><div class='alert alert-success'>Username has been successfully registered!");

                            } 
                     
                     console.log('wot'); 
                     console.log('end of else'); 
                         }); 
		}
		return false; 
		
	}); 
	
	
	
}); 