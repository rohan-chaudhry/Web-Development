<?php

if(isset($_POST['submit'])){
if( strpos(file_get_contents("./passwd.txt") , $_GET[$_POST['username']]) !== false) {
        echo 'Please choose a unique username.'; 
    }
	else{
                echo 'You have successfully registered, and your 2 minute cookie is in session.'; 
        	$str = $_POST['username'] . " : " . $_POST['pwd'] . "\n"; 
        	$fh = fopen("./passwd.txt", "a"); 
        	fwrite($fh, $str); 
        	fclose($fh);	
                setcookie("user", $_POST['username'], time()+120); // two min cookie 
	
        } 
}  

?> 

<html>
  <head>
    <title> Rohan Chaudhry | Hwk13 New User </title>
  </head>
  <body>
    <h1> Newspaper of Truth </h1> 
    <h3>  Rohan Chaudhry | Hwk 13 | rc43755 </h3>
    <div align='center' > 
      <form method = "post" action = "">
        <h1>New User Registration</h1> 
        <p>Please choose a unique username when registering.</p> 
        <div align='center'> 
          Username: <input name='username' type='text' /><br/>
          Password: <input name='pwd' type='text' /><br/>
          <input type = "submit" name='submit' value = "Submit" />
        </div>
      </form>  
  </div> 
  </body>
</html>