<?php

/*
if first time visiting, show a normal landing page 
if (! loggedIn) && (attempts to access links) { display login prompt } 
    LOGIN { if username NOT in txt file { allow it } 
            else { prompt another login} 
		
else{ while COOKIE isset { allow access to pages } 
*/

 
if(isset($_POST['submit'])){
   setcookie("user", $_POST['username'], time()+120); // two min cookie 
   if( strpos(file_get_contents("./passwd.txt"),$_GET[$_POST['username']]) !== false) {
        echo 'Please choose a unique username.'; 
    }
   else{
	echo 'You are successfully logged in!';
        $str = $_POST['username'] . " : " . $_POST['pwd'] . "\n"; 
        $fh = fopen("./passwd.txt", "a"); 
        fwrite($fh, $str); 
        fclose($fh);		
   } 

} 	
/*
if($_POST['username'] !== 'Enter Username Here' && $cookie_name !== ''){    
    if( strpos(file_get_contents("./passwd.txt"),$_GET[$_POST['username']]) !== false) {
        echo 'Please choose a unique username.'; 
    }
	else{
		echo 'right';
        	$str = $_POST['username'] . " : " . $_POST['pwd'] . "\n"; 
        	$fh = fopen("./passwd.txt", "a"); 
        	fwrite($fh, $str); 
        	fclose($fh);		} 
  }  
*/ 

?>

  <html>
  <head>
  <title> Rohan Chaudhry | Hwk13 Homepage </title>
  </head>
  <body>
  <h1> Newspaper of Truth </h1> 
  <h3>  Rohan Chaudhry | Hwk 13 | rc43755 </h3>
  <div align='center' > 
  <form method = "post" action = "">

  <h1>Top Headlines</h1> 
  <p>Note: You must log in to view news stories.</p> 
  <div align='center'> 
  Username: <input name='username' type='text' /><br/>
  Password: <input name='pwd' type='text' /><br/>
  <input type = "submit" name='submit' value = "Submit" />
  </div> 
  <span><br/><a href='hwk13-newuser.php' target='_blank'>New Users Click Here</a></span> 

  <p><hr/>
	<strong><a href="hwk13-p1.php" target='_blank'>Kanye West Is Back Again </a></strong><br/>
	<strong><a href="hwk13-p2.php" target='_blank'>Is Texas Football Back?</a></strong><br/>
	<strong><a href="hwk13-p3.php" target='_blank'>Basketball vs. Baseball: An Analysis</a></strong><br/>
	<strong><a href="hwk13-p4.php" target='_blank'>Is Water Actually Wet?</a> </strong><br/>
	<strong><a href="hwk13-p5.php" target='_blank'>Future Weather </a></strong><br/>
  </p> 

</div>

  
  </form>
  </body>
  </html>