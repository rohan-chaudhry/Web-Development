<?php
if(isset($_COOKIE['user'])) {
 echo 'You are Logged In';

 
print <<<PAGE1
<html>
<head>
  <title> Rohan Chaudhry | Article 1 </title>
</head>
  <body>
  <h1> Newspaper of Truth </h1> 
  <h3>  Rohan Chaudhry | Hwk 13 | rc43755 </h3>
  <div align='center' > 
    <p> Texas Football is definitely not back, but it's definitely on the way.</p>
  </div>
  </body>
</html> 
PAGE1;
 
} 


else{
 echo 'Newspaper of Truth: To view the following article, please log in or register on the homepage.'; 

 print <<<PAGE2
  <br/><br/> 
  Username: <input name='username' type='text' /><br/>
  Password: <input name='pwd' type='text' /><br/>
  <input type = "submit" name='submit' value = "Submit" />
  <br/><br/><br/>
  If you do not have an account, please <a href='https://fall-2018.cs.utexas.edu/cs329e-mitra/rohan97/hwk13-newuser.php' target='_blank'>click here</a>. 

PAGE2;

} 









?>

